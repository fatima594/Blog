<?php $__env->startSection('content'); ?>

    <!-- Blog section start -->
    <div class="blog_section layout_padding">
        <div class="container">
            <!-- Section title and bullet icon -->
            <div class="row mb-4">
                <div class="col-md-12 text-center">
                    <h1 class="about_taital">Our Blog</h1>
                    <div class="bulit_icon"><img src="images/bulit-icon.png" alt="Icon"></div>
                </div>
            </div>

            <!-- Blog list -->
            <div class="blog_section_2">
                <div class="row">
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 mb-4">
                            <div class="blog_box border rounded p-3">
                                <div class="blog_img mb-3">
                                    <!-- Improve image display -->
                                    <img src="<?php echo e(asset('storage/blogs/' . basename($blog->image))); ?>" alt="<?php echo e($blog->title); ?>" class="img-fluid" style="width: 100%; height: auto; object-fit: cover; border-radius: 8px;">
                                </div>

                                <h4 class="prep_text"><?php echo e($blog->title); ?></h4>

                                <div class="read_bt mt-3">
                                    <a style="background:  #ffd54f; color: whitesmoke" href="<?php echo e(route('single', $blog->id)); ?>" class="btn btn-primary">Read More</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Pagination links -->
                <div class="mt-4">
                    
                </div>
            </div>
        </div>
    </div>
    <!-- Blog section end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\healthyfood\blog-app\resources\views/layouts/blogpage.blade.php ENDPATH**/ ?>