<?php $__env->startSection('title', 'topic Posts'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h1 class="mb-4">Blog Posts</h1>

        <!-- Success Message -->
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <!-- Create New Blog Post Button -->
        <a href="<?php echo e(route('admin.topics.create')); ?>" class="btn btn-primary mb-3">Create New topic </a>

        <!-- Blog Posts Table -->
        <table class="table table-striped table-bordered">
            <thead>
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>description</th>
                <th>Image</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($topic->id); ?></td>
                    <td><?php echo e($topic->title); ?></td>
                    <td><?php echo e(Str::limit($topic->description, 50)); ?></td>
                    <td>
                        <?php if($topic->image): ?>
                            <img src="<?php echo e(asset('storage/topic/' . basename($topic->image))); ?>" alt="<?php echo e($topic->title); ?>" width="50">
                        <?php else: ?>
                            <span>No Image</span>
                        <?php endif; ?>

                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.topics.show', $topic->id)); ?>" class="btn btn-info btn-sm">Show</a>
                        <a href="<?php echo e(route('admin.topics.edit', $topic->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                        <form action="<?php echo e(route('admin.topics.destroy', $topic->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="text-center">No topic  available</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\healthyfood\blog-app\resources\views/layouts/topic/index.blade.php ENDPATH**/ ?>