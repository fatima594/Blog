<!-- resources/views/errors/post_not_found.blade.php -->


<?php $__env->startSection('title', 'Post Not Found'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Sorry, the post you are looking for could not be found.</h1>
        <p>Please check the URL or return to the <a href="<?php echo e(url('/')); ?>">home page</a>.</p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\healthyfood\blog-app\resources\views/errors/post_not_found.blade.php ENDPATH**/ ?>