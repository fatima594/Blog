<!-- resources/views/categories/show.blade.php -->


<?php $__env->startSection('title', $category->name); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h1><?php echo e($category->name); ?></h1>
        <a href="<?php echo e(route('admin.categories.index')); ?>" class="btn btn-secondary mt-3">Back to Categories List</a>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\healthyfood\blog-app\resources\views/layouts/category/show.blade.php ENDPATH**/ ?>