<?php $__env->startSection('content'); ?>

    <form action="<?php echo e(route('send.contact')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="contact_section layout_padding">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <h1 class="contact_taital">Get In Touch</h1>
                        <div class="bulit_icon"><img src="images/bulit-icon.png" alt="Icon"></div>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="contact_section_2">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="mail_section_1">
                                <input type="text" class="mail_text" placeholder="Your Name" name="name" value="<?php echo e(old('name')); ?>">
                                <input type="text" class="mail_text" placeholder="Your Email" name="email" value="<?php echo e(old('email')); ?>">
                                <input type="text" class="mail_text" placeholder="Your Phone" name="phone" value="<?php echo e(old('phone')); ?>">
                                <textarea name="message" class="massage-bt" placeholder="Message" rows="5" id="comment"><?php echo e(old('message')); ?></textarea>
                                <button type="submit" class="send_bt">SEND</button>
                            </div>
                        </div>
                        <div class="map_main">
                            <div class="map-responsive">
                                <iframe src="https://www.google.com/maps/embed/v1/place?key=AIzaSyA0s1a7phLN0iaD6-UE7m4qP-z21pH0eSc&amp;q=Eiffel+Tower+Paris+France" width="250" height="500" frameborder="0" style="border:0; width: 100%;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\healthyfood\blog-app\resources\views/layouts/pages/contact.blade.php ENDPATH**/ ?>