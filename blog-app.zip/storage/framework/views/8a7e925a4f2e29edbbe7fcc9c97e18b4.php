<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h1 class="mb-4">Headers</h1>
        <a href="<?php echo e(route('header.create')); ?>" class="btn btn-primary mb-3">Add New Header</a>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <table class="table table-bordered">
            <thead>
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Name</th>
                <th>Description</th>
                <th>Image</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($header->id); ?></td>
                    <td><?php echo e($header->title); ?></td>
                    <td><?php echo e($header->name); ?></td>
                    <td><?php echo e($header->description); ?></td>
                    <td>
                        <?php if($header->image): ?>
                            <img src="<?php echo e(Storage::url($header->image)); ?>" alt="<?php echo e($header->title); ?>" width="100">
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('header.show', $header->id)); ?>" class="btn btn-info btn-sm">View</a>
                        <a href="<?php echo e(route('header.edit', $header->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                        <form action="<?php echo e(route('header.destroy', $header->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\healthyfood\blog-app\resources\views/layouts/header/index.blade.php ENDPATH**/ ?>