<!-- resources/views/emails/test.blade.php -->
<p>New comment received:</p>
<p><strong>Name:</strong> <?php echo e($comment->name); ?></p>
<p><strong>Email:</strong> <?php echo e($comment->email); ?></p>
<p><strong>Comment:</strong> <?php echo e($comment->comment); ?></p>
<p><strong>Website:</strong> <?php echo e($comment->website); ?></p>
<?php /**PATH C:\xampp\htdocs\healthyfood\blog-app\resources\views/emails/test.blade.php ENDPATH**/ ?>