<?php $__env->startSection('content'); ?>
<!-- coffee section start -->
<div class="coffee_section layout_padding">
    <div class="container">
        <div class="row">
            <h1 class="coffee_taital">OUR Coffee OFFER</h1>
            <div class="bulit_icon"><img src="images/bulit-icon.png"></div>
        </div>
    </div>
    <div class="coffee_section_2">
        <div id="main_slider" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-3 col-md-6">
                                <div class="coffee_img"><img src="images/img-1.png"></div>
                                <h3 class="types_text">TYPES OF COFFEE</h3>
                                <p class="looking_text">looking at its layout. The point of</p>
                                <div class="read_bt"><a href="#">Read More</a></div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="coffee_img"><img src="images/img-2.png"></div>
                                <h3 class="types_text">BEAN VARIETIES</h3>
                                <p class="looking_text">looking at its layout. The point of</p>
                                <div class="read_bt"><a href="#">Read More</a></div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="coffee_img"><img src="images/img-3.png"></div>
                                <h3 class="types_text">COFFEE & PASTRY</h3>
                                <p class="looking_text">looking at its layout. The point of</p>
                                <div class="read_bt"><a href="#">Read More</a></div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="coffee_img"><img src="images/img-4.png"></div>
                                <h3 class="types_text">COFFEE TO GO</h3>
                                <p class="looking_text">looking at its layout. The point of</p>
                                <div class="read_bt"><a href="#">Read More</a></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-3 col-md-6">
                                <div class="coffee_img"><img src="images/img-1.png"></div>
                                <h3 class="types_text">TYPES OF COFFEE</h3>
                                <p class="looking_text">looking at its layout. The point of</p>
                                <div class="read_bt"><a href="#">Read More</a></div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="coffee_img"><img src="images/img-2.png"></div>
                                <h3 class="types_text">BEAN VARIETIES</h3>
                                <p class="looking_text">looking at its layout. The point of</p>
                                <div class="read_bt"><a href="#">Read More</a></div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="coffee_img"><img src="images/img-3.png"></div>
                                <h3 class="types_text">COFFEE & PASTRY</h3>
                                <p class="looking_text">looking at its layout. The point of</p>
                                <div class="read_bt"><a href="#">Read More</a></div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="coffee_img"><img src="images/img-4.png"></div>
                                <h3 class="types_text">COFFEE TO GO</h3>
                                <p class="looking_text">looking at its layout. The point of</p>
                                <div class="read_bt"><a href="#">Read More</a></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-3 col-md-6">
                                <div class="coffee_img"><img src="images/img-1.png"></div>
                                <h3 class="types_text">TYPES OF COFFEE</h3>
                                <p class="looking_text">looking at its layout. The point of</p>
                                <div class="read_bt"><a href="#">Read More</a></div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="coffee_img"><img src="images/img-2.png"></div>
                                <h3 class="types_text">BEAN VARIETIES</h3>
                                <p class="looking_text">looking at its layout. The point of</p>
                                <div class="read_bt"><a href="#">Read More</a></div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="coffee_img"><img src="images/img-3.png"></div>
                                <h3 class="types_text">COFFEE & PASTRY</h3>
                                <p class="looking_text">looking at its layout. The point of</p>
                                <div class="read_bt"><a href="#">Read More</a></div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="coffee_img"><img src="images/img-4.png"></div>
                                <h3 class="types_text">COFFEE TO GO</h3>
                                <p class="looking_text">looking at its layout. The point of</p>
                                <div class="read_bt"><a href="#">Read More</a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <a class="carousel-control-prev" href="#main_slider" role="button" data-slide="prev">
                <i class="fa fa-arrow-left"></i>
            </a>
            <a class="carousel-control-next" href="#main_slider" role="button" data-slide="next">
                <i class="fa fa-arrow-right"></i>
            </a>
        </div>
    </div>
</div>
<!-- coffee section end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\healthyfood\blog-app\resources\views/layouts/pages/topic.blade.php ENDPATH**/ ?>