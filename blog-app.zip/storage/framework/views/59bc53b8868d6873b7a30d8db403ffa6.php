<!-- resources/views/categories/create.blade.php -->


<?php $__env->startSection('title', 'Create Category'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h1>Create Category</h1>
        <form action="<?php echo e(route('admin.categories.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" id="name" name="name" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Create</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\healthyfood\blog-app\resources\views/layouts/category/create.blade.php ENDPATH**/ ?>