    <?php $__env->startSection('content'); ?>

  <?php echo $__env->make('layouts.topicpage' , ['blogs' =>$blogs], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\healthyfood\blog-app\resources\views/home.blade.php ENDPATH**/ ?>