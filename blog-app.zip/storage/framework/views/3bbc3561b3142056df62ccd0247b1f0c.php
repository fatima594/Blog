<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h1 class="mb-4">Edit Header</h1>

        <form action="<?php echo e(route('header.update', $header->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label for="title">Title</label>
                <input type="text" name="title" id="title" class="form-control" value="<?php echo e($header->title); ?>" required>
            </div>

            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" name="name" id="name" class="form-control" value="<?php echo e($header->name); ?>" required>
            </div>

            <div class="form-group">
                <label for="description">Description</label>
                <textarea name="description" id="description" class="form-control" required><?php echo e($header->description); ?></textarea>
            </div>

            <div class="form-group">
                <label for="image">Image</label>
                <input type="file" name="image" id="image" class="form-control">
                <?php if($header->image): ?>
                    <img src="<?php echo e(Storage::url($header->image)); ?>" alt="<?php echo e($header->title); ?>" width="100" class="mt-2">
                <?php endif; ?>
            </div>

            <button type="submit" class="btn btn-primary">Update Header</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\healthyfood\blog-app\resources\views/layouts/header/edit.blade.php ENDPATH**/ ?>