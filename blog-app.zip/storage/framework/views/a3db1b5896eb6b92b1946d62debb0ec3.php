<?php $__env->startSection('content'); ?>

    <section class="container">
        <div class="page-container">
            <div class="page-content">
                <div class="card">
                    <div class="card-header pt-0">
                        <h3 style="padding-top: 100px; text-align: center" class="card-title mb-4"><?php echo e($blog->title); ?></h3>
                        <div class="blog-media mb-4">
                            <?php if($blog->image): ?>
                                <img src="<?php echo e(asset('storage/blogs/' . basename($blog->image))); ?>" alt="<?php echo e($blog->title); ?>" class="w-100">
                            <?php else: ?>
                                <img src="assets/imgs/default-image.jpg" alt="Default Image" class="w-100">
                            <?php endif; ?>
                            <a href="#" class="badge badge-primary">#<?php echo e($blog->categories); ?></a>
                        </div>
                        <small class="small text-muted">
                            <a href="#" class="text-muted">BY Admin</a>
                            <span class="px-2">·</span>
                            <span><?php echo e($blog->created_at->format('F j, Y')); ?></span>
                            <span class="px-2">·</span>
                            <a href="#" class="text-muted">32 Comments</a>
                        </small>
                    </div>
                    <div class="card-body border-top">
                        <p class="my-3"><?php echo e($blog->description); ?></p>
                    </div>

                    <h6 class="mt-5 mb-3 text-center"><a href="#" class="text-dark">Write Your Comment</a></h6>
                    <hr>
                    <form>
                        <div class="form-row">
                            <div class="col-12 form-group">
                                <textarea name="" id="" cols="30" rows="10" class="form-control" placeholder="Enter Your Comment Here"></textarea>
                            </div>
                            <div class="col-sm-4 form-group">
                                <input type="text" class="form-control" value="Name">
                            </div>
                            <div class="col-sm-4 form-group">
                                <input type="email" class="form-control" placeholder="Email">
                            </div>
                            <div class="col-sm-4 form-group">
                                <input type="url" class="form-control" placeholder="Website">
                            </div>
                            <div class="form-group col-12">
                                <button class="btn btn-primary btn-block">Post Comment</button>
                            </div>
                        </div>
                    </form>
                </div>

                <h6 class="mt-5 text-center">Related Posts</h6>
                <hr>
                <div class="row">
                    <!-- You can add related posts here -->
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\healthyfood\blog-app\resources\views/layouts/blog/detailsgarlic.blade.php ENDPATH**/ ?>