<?php $__env->startSection('content'); ?>


<!-- blog section start -->
<div class="blog_section layout_padding">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="about_taital">Our Blog</h1>
                <div class="bulit_icon"><img src="images/bulit-icon.png"></div>
            </div>
        </div>
        <div class="blog_section_2">
            <div class="row">
                <div class="col-md-6">
                    <div class="blog_box">
                        <div class="blog_img"><img src="images/blog-img1.png"></div>
                        <h4 class="date_text">05 April</h4>
                        <h4 class="prep_text">PREP TECHNIQUES Coffee</h4>
                        <p class="lorem_text">distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a moredistracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more</p>
                    </div>
                    <div class="read_bt"><a href="#">Read More</a></div>
                </div>
                <div class="col-md-6">
                    <div class="blog_box">
                        <div class="blog_img"><img src="images/blog-img2.png"></div>
                        <h4 class="date_text">05 April</h4>
                        <h4 class="prep_text">PREP TECHNIQUES Coffee</h4>
                        <p class="lorem_text">distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a moredistracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more</p>
                    </div>
                    <div class="read_bt"><a href="#">Read More</a></div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- blog section end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\healthyfood\blog-app\resources\views/layouts/pages/blog.blade.php ENDPATH**/ ?>