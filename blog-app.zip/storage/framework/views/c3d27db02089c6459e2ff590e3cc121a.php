<?php $__env->startSection('title', 'Blog Posts'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h1 class="mb-4">Blog Posts</h1>

        <!-- Success Message -->
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <!-- Create New Blog Post Button -->
        <a href="<?php echo e(route('admin.blogs.create')); ?>" class="btn btn-primary mb-3">Create New Blog Post</a>

        <!-- Blog Posts Table -->
        <table class="table table-striped table-bordered">
            <thead>
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Slug</th>
                <th>Category</th>
                <th>Description</th>
                <th>Description2</th>
                <th>Description3</th>
                <th>Description4</th>
                <th>Description5</th>
                <th>Description6</th>
                <th>Image</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($blog->id); ?></td>
                    <td><?php echo e($blog->title); ?></td>
                    <td><?php echo e($blog->slug); ?></td>
                    <td><?php echo e($blog->category->name ?? 'No Category'); ?></td>
                    <td><?php echo e(Str::limit($blog->description, 50)); ?></td>
                    <td><?php echo e(Str::limit($blog->description2, 50)); ?></td>
                    <td><?php echo e(Str::limit($blog->description3, 50)); ?></td>
                    <td><?php echo e(Str::limit($blog->description4, 50)); ?></td>
                    <td><?php echo e(Str::limit($blog->description5, 50)); ?></td>
                    <td><?php echo e(Str::limit($blog->description6, 50)); ?></td>
                    <td>
                        <?php if($blog->image): ?>
                            <img src="<?php echo e(asset('storage/blogs/' . basename($blog->image))); ?>" alt="<?php echo e($blog->title); ?>" width="50">
                        <?php else: ?>
                            <span>No Image</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.blogs.show', $blog->id)); ?>" class="btn btn-info btn-sm">Show</a>
                        <a href="<?php echo e(route('admin.blogs.edit', $blog->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                        <form action="<?php echo e(route('admin.blogs.destroy', $blog->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center">No blog posts available</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\healthyfood\blog-app\resources\views/layouts/blog/index.blade.php ENDPATH**/ ?>