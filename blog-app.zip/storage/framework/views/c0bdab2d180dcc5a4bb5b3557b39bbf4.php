<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h1 class="mb-4"><?php echo e($header->title); ?></h1>

        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Name: <?php echo e($header->name); ?></h5>
                <p class="card-text">Description: <?php echo e($header->description); ?></p>

                <?php if($header->image): ?>
                    <img  src="<?php echo e(Storage::url($header->image)); ?>" alt="<?php echo e($header->title); ?>" class="img-fluid" width="100">
                <?php endif; ?>
            </div>
        </div>

        <a href="<?php echo e(route('header.index')); ?>" class="btn btn-secondary mt-3">Back to List</a>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\healthyfood\blog-app\resources\views/layouts/header/show.blade.php ENDPATH**/ ?>