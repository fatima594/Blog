
<!-- resources/views/emails/test.blade.php -->
<p>New comment received:</p>
<p><strong>Name:</strong> <?php echo e($contact->name); ?></p>
<p><strong>Email:</strong> <?php echo e($contact->phone); ?></p>
<p><strong>Comment:</strong> <?php echo e($contact->email); ?></p>
<p><strong>Website:</strong> <?php echo e($contact->message); ?></p>
<?php /**PATH C:\xampp\htdocs\healthyfood\blog-app\resources\views/emails/contactnotification.blade.php ENDPATH**/ ?>