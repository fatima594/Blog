<?php $__env->startSection('title', 'Topic Details'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <h1 class="card-title"><?php echo e($topic->title); ?></h1>
                        <?php if($topic->image): ?>
                            <img src="<?php echo e(asset('storage/' . $topic->image)); ?>" class="img-fluid mb-3" alt="Topic Image">
                        <?php endif; ?>
                        <p class="card-text"><?php echo e($topic->description); ?></p>
                        <a href="<?php echo e(route('topics.edit', $topic->id)); ?>" class="btn btn-warning">Edit</a>
                        <form action="<?php echo e(route('topics.destroy', $topic->id)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                        <a href="<?php echo e(route('topics.index')); ?>" class="btn btn-secondary mt-2">Back to List</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\healthyfood\blog-app\resources\views/layouts/topic/show.blade.php ENDPATH**/ ?>