<?php $__env->startSection('content'); ?>
    <section class="container my-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card mb-4">
                    <div class="card-header text-center bg-light">
                        <h3 class="card-title"><?php echo e($blog->title); ?></h3>
                        <div class="blog-media mb-4">
                            <img src="<?php echo e(asset('storage/blogs/' . basename($blog->image))); ?>" alt="<?php echo e($blog->title); ?>" class="img-fluid rounded">
                            <a href="#" class="badge badge-primary mt-2">#<?php echo e($blog->category->name); ?></a>
                        </div>
                        <small class="text-muted">
                            <a href="#" class="text-muted">BY Admin</a>
                            <span class="px-2">·</span>
                            <span><?php echo e($blog->created_at->format('F d Y')); ?></span>
                            <span class="px-2">·</span>
                            <a href="#" class="text-muted">32 Comments</a>
                        </small>
                    </div>
                    <div class="card-body">
                        <p class="my-3"><?php echo e($blog->description2); ?></p>
                    </div>

                    <div class="card-footer bg-light">
                        <h6 class="mt-5 mb-3 text-center">Comments (4)</h6>
                        <hr>
                        <div class="media mb-4">
                            <img src="<?php echo e(asset('path/to/avatar-1.jpg')); ?>" class="mr-3 rounded-circle" alt="...">
                            <div class="media-body">
                                <h6 class="mt-0">Janice Wilder</h6>
                                <p>Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin.</p>
                                <a href="#" class="text-dark small font-weight-bold"><i class="ti-back-right"></i> Reply</a>
                            </div>
                        </div>
                        <!-- Add more comment sections here -->

                        <h6 class="mt-5 mb-3 text-center">Write Your Comment</h6>
                        <hr>
                        <form>
                            <div class="form-group">
                                <textarea class="form-control" rows="5" placeholder="Enter Your Comment Here"></textarea>
                            </div>
                            <div class="form-row">
                                <div class="col-sm-4 form-group">
                                    <input type="text" class="form-control" placeholder="Name">
                                </div>
                                <div class="col-sm-4 form-group">
                                    <input type="email" class="form-control" placeholder="Email">
                                </div>
                                <div class="col-sm-4 form-group">
                                    <input type="url" class="form-control" placeholder="Website">
                                </div>
                                <div class="form-group col-12">
                                    <button type="submit" class="btn btn-primary btn-block">Post Comment</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <h6 class="mt-5 text-center">Related Posts</h6>
                <hr>
                <div class="row">
                    <?php $__currentLoopData = $relatedBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-4 mb-4">
                            <div class="card">
                                <div class="card-header p-0">
                                    <img src="<?php echo e(asset('storage/blogs/' . basename($related->image))); ?>" alt="<?php echo e($related->title); ?>" class="img-fluid rounded">
                                    <a href="#" class="badge badge-primary mt-2 position-absolute" style="top: 10px; right: 10px;">#<?php echo e($related->category->name); ?></a>
                                </div>
                                <div class="card-body">
                                    <h6 class="card-title"><a href="<?php echo e(route('blogs.show', $related->id)); ?>" class="text-dark"><?php echo e($related->title); ?></a></h6>
                                    <small class="text-muted"><?php echo e($related->created_at->format('F d Y')); ?></small>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <h6 class="mt-5 text-center">Categories</h6>
                <hr>
                <div class="row">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-4 mb-4">
                            <div class="card">
                                <div class="card-body text-center">
                                    <a href="<?php echo e(route('categories.show', $category->id)); ?>" class="badge badge-primary">#<?php echo e($category->name); ?></a>
                                    <h6 class="card-title mt-3"><?php echo e($category->name); ?></h6>
                                    <small class="text-muted"><?php echo e($category->blogs_count); ?> Posts</small>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\healthyfood\blog-app\resources\views/layouts/singlepost.blade.php ENDPATH**/ ?>