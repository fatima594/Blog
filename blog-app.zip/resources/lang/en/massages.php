
<?php


return [
'welcome' => 'Welcome to our website!',
'greeting' => 'Hello, :name!',
];

