<?php
// resources/lang/ar/messages.php


return [
    'welcome' => 'مرحبا بك في تطبيقنا',
    'login' => 'تسجيل الدخول',
    'register' => 'إنشاء حساب',
    // أضف المزيد من الترجمات حسب الحاجة
];
