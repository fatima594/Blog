
@extends('master')

    @section('content')

  @include('layouts.topicpage' , ['blogs' =>$blogs])

    @endsection

