<!-- resources/views/emails/test.blade.php -->
<p>New comment received:</p>
<p><strong>Name:</strong> {{ $comment->name }}</p>
<p><strong>Email:</strong> {{ $comment->email }}</p>
<p><strong>Comment:</strong> {{ $comment->comment }}</p>
<p><strong>Website:</strong> {{ $comment->website }}</p>
