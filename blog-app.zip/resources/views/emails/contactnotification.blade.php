
<!-- resources/views/emails/test.blade.php -->
<p>New Contact received:</p>
<p><strong>Name:</strong> {{ $contact->name }}</p>
<p><strong>Email:</strong> {{ $contact->phone }}</p>
<p><strong>Comment:</strong> {{ $contact->email }}</p>
<p><strong>Website:</strong> {{ $contact->message }}</p>
