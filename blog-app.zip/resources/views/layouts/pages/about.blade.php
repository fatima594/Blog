
@extends('master')

@section('content')

<div class="about_section layout_padding">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="about_taital">About Our shop</h1>
                <div class="bulit_icon"><img src="images/bulit-icon.png"></div>
            </div>
        </div>
        <div class="about_section_2 layout_padding">
            <div class="image_iman"><img src="images/about-img.png" class="about_img"></div>
            <div class="about_taital_box">
                <h1 class="about_taital_1">Coffee distribution '</h1>
                <p class=" about_text">has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editorhas a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editor</p>
                <div class="readmore_btn"><a href="#">Read More</a></div>
            </div>
        </div>
    </div>
</div>


@endsection
