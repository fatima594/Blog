<?php
namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreCommentRequest extends FormRequest
{
    public function authorize()
    {
        // You can specify who is authorized to use this request here
        return true;
    }

    public function rules()
    {
        return [
            'comment' => 'required|string',
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'website' => 'required|string|max:255',
            'blog_id' => 'required|exists:blogs,id', // Ensure that the blog exists
        ];
    }
}
