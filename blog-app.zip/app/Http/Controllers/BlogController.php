<?php
// App\Http\Controllers\BlogController.php
namespace App\Http\Controllers;

use App\Http\Requests\StoreBlogRequest;
use App\Models\Blog;
use App\Models\Category; // Ensure Category model is imported
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;

class BlogController extends Controller
{
    public function index()
    {
        App::setLocale('en');
        $blogs = Blog::with('category')->get(); // Load the category relation
        return view('layouts.blog.index', compact('blogs'));
    }

    public function create()
    {
        $categories = Category::all(); // Load all categories
        return view('layouts.blog.create', compact('categories'));
    }

    public function store(StoreBlogRequest $request)
    {
        $request->validate([
            'title' => 'required',
            'slug' => 'required|unique:blogs',
            'description' => 'required',
            'description2' => 'required',
            'description3' => 'required',
            'description4' => 'required',
            'description5' => 'required',
            'description6' => 'required',
            'image' => 'image|nullable',
            'category_id' => 'required|exists:categories,id', // Ensure valid category_id
        ]);

        $imagePath = $request->hasFile('image') ? $request->file('image')->store('public/blogs') : null;

        Blog::create([
            'title' => $request->title,
            'slug' => $request->slug,
            'description' => $request->description,
            'description2' => $request->description2,
            'description3' => $request->description3,
            'description4' => $request->description4,
            'description5' => $request->description5,
            'description6' => $request->description6,
            'category_id' => $request->category_id, // Store category_id
            'image' => $imagePath,
        ]);

        return redirect()->route('admin.blogs.index')->with('success', 'Blog post created successfully.');
    }

    public function show($id)
    {
        $blog = Blog::with('category')->findOrFail($id); // Load the category relation

        if (!$blog) {
            throw new PostNotFoundException("Post with ID $id was not found.");
        }

        $blog = Blog::with('comments')->findOrFail($id);

        return view('layouts.blog.show', compact('blog'));
    }

    public function edit($id)
    {
        $blog = Blog::findOrFail($id);
        $categories = Category::all(); // Load all categories for selection
        return view('layouts.blog.edit', compact('blog', 'categories'));
    }

    public function update(StoreBlogRequest $request, $id)
    {


        $request->validate([
            'title' => 'required',
            'slug' => ['required', Rule::unique('blogs')->ignore($id)],
            'description' => 'required',
            'description2' => 'required',
            'description3' => 'required',
            'description4' => 'required',
            'description5' => 'required',
            'description6' => 'required',
            'category_id' => 'required|exists:categories,id', // Ensure valid category_id
            'image' => 'nullable|image',
        ]);

        $blog = Blog::findOrFail($id);

        if ($request->hasFile('image')) {
            if ($blog->image) {
                Storage::disk('public')->delete($blog->image);
            }
            $imagePath = $request->file('image')->store('blogs', 'public');
            $blog->image = $imagePath;
        }

        $blog->title = $request->input('title');
        $blog->slug = $request->input('slug');
        $blog->description = $request->input('description');
        $blog->description2 = $request->input('description2');
        $blog->description3 = $request->input('description3');
        $blog->description4 = $request->input('description4');
        $blog->description5 = $request->input('description5');
        $blog->description6 = $request->input('description6');
        $blog->category_id = $request->input('category_id'); // Update category_id

        $blog->save();

        return redirect()->route('admin.blogs.index')->with('success', 'Blog post updated successfully.');
    }

    public function destroy($id)
    {
        $blog = Blog::findOrFail($id);
        if ($blog->image) {
            Storage::delete($blog->image);
        }
        $blog->delete();

        return redirect()->route('admin.blogs.index')->with('success', 'Blog post deleted successfully.');
    }

}
