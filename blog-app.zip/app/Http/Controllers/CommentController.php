<?php

// app/Http/Controllers/CommentController.php

namespace App\Http\Controllers;

use App\Mail\CommentNotification;
use App\Http\Requests\StoreCommentRequest;
use App\Models\Comment;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

class CommentController extends Controller
{
    public function store(Request $request)
    {
        // Validate the request data
        $request->validate([
            'comment' => 'required|string|max:500',
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'website' => 'nullable|url',
            'blog_id' => 'required|exists:blogs,id'
        ]);

        // Create a new comment
        Comment::create([
            'comment' => $request->input('comment'),
            'name' => $request->input('name'),
            'email' => $request->input('email'),
            'website' => $request->input('website'),
            'blog_id' => $request->input('blog_id')
        ]);
    }
}
